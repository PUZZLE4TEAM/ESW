$(function(){
	
    $("#btnSend").on("click", function(e){

        var userName = $("#userName").val();
        var userPass = $("#userPass").val();

        e.preventDefault();

        $.ajax({
            url: 'nome_da_pagina_alvo.php',
            type: 'POST',
            async: true,
            data: {userName: userName, userPass: userPass},
            success: function(res) {
                if( res != "" ){
                    res = $.parseJSON(res);

                }else{

                }
            },
            error: function(xhr, er, err){ console.log( xhr ); }
        });

    });

});