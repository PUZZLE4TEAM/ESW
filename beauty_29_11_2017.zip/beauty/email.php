<!DOCTYPE HTML>
<html lang='pt'>
    <head>
        <meta charset='utf-8' />
        <meta name='viewport' content='width=device-width, initial-scale=1' />
        <title>angoHair</title>
        <style>
            body{
                background: #eee;
                font-family: arial;
            }
            main{
                float: left;
                width: 90%;
                margin-left: 5%;
                background: #fff;
                border-radius: 10px;
            }
            img{
                float: left; width: 100px;
            }
            h1{text-align: center; color: #f50}
            p{
                float: left;
                width: 100%;
                padding: 10px;
                text-align: justify;
            }
            span{float: left; width: 100%; text-align: center; border-bottom: 1px solid #aaa; padding-bottom: 20px;}
        </style>
    </head>
    <body>
          
        <main>
            <h1>Beauty</h1>
            <span>A paixão pela sua beleza</span>
            
            <p>
                Olá Sr(a), a sua conta aberta no nosso site, está pronta!
                Para acessar basta <a href='#' target="_blank">clicar aqui</a> <br><br>
                
                Se voce não solicitou nenhum registro, ignore essa mensagem ou entre em contacto <a href='#'>connosco</a>.
               
            </p>
            <p>
                 Obrigado!
            </p>
        </main>
        
    </body>
</html>
