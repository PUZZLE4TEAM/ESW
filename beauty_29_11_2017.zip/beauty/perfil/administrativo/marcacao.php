<?php $page = 'marcacao'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            <p>&nbsp;</p>
            <div class="row" id="litleDash">
                <div class="col-md-3">
                    <h2>20</h2>
                    <span>Solicitude de Marcação</span>
                </div>
                <div class="col-md-3">
                    <h2>10</h2>
                    <span>Clientes com Solicitação</span>
                </div>
                <div class="col-md-3">
                    <h2>2/10</h2>
                    <span>Serviços Solicitados</span>
                </div>
                <div class="col-md-3">
                    <h2>20/40</h2>
                    <span>Profissionais Solicitados</span>
                </div>
            </div>
            <p>&nbsp;</p><p>&nbsp;</p>

            <form method="post">
                <div class="form-group" id="search">
                    <div class="input-group">
                        <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                        <input type="search" name="filtro" placeholder="Faça uma Busca Aqui" class="form-control">
                    </div>
                </div>
            </form>
            <table class="table table-bordered table-hover table-responsive table-striped text-center" id="tblMarcacao">
                <thead>
                    <tr>
                        <th class="text-center">Data de Modificação</th>
                        <th class="text-center">Cliente</th>
                        <th class="text-center">E-mail</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center" colspan="3">Acção</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i=0; $i < 10; $i++):?>
                    <tr>
                        <td>20-10-2017 <strong>10:50</strong></td>
                        <td>Inês Martins</td>
                        <td>ines.martins@gov.co.ao</td>
                        <td>Espera</td>
                        <td><a href="#" data-toggle="modal" data-target="#verMarcacao"><i class="fa fa-eye" data-toggle="tooltip" data-placement="left" title="Reagendar"></i></a></td>
                        <td><a href="#"><i class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="left" title="Aceitar"></i></a></td>                                    
                        <td><a href="#" data-toggle="modal" data-target="#modalConfirmar"><i class="fa fa-remove" data-toggle="tooltip" data-placement="left" title="Rejeitar"></i></a></td>            
                    </tr>
                    <?php endfor;?>
                </tbody>
            </table>
        </main>
        
        <?php include 'modalConfirmar.php';?>
        <div id="verMarcacao" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <div class="row">
                      <div class="col-md-10">
                          <h3 class="modal-title">Solicitação de Marcação</h3>
                      </div>
                     
                  </div>
                </div>

                    <div class="modal-body">
                        <!-- k_change -->
                        <h5>Pendentes</h5>
                        <table class="table table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th>Categoria</th>
                                    <th>Serviço</th>
                                    <th>Profissional</th>
                                    <th>Data</th>
                                    <th>Hora</th>
                                    <th colspan="3">Opçäo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                                    <td><i class="fa fa-remove" data-toggle="tooltip" data-placement="top" title="Rejeitar"></i></td>
                                    <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="top" title="Aceitar"></a></td>
                                    <td><a a href="#" data-toggle="modal" data-target="#reagendarMarcacao"><i class="fa fa-calendar" data-toggle="tooltip" data-placement="top" title="Reagendar" ></i></a></td>
                                </tr>
                                <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                                    <td><a href="#" class="fa fa-remove" data-toggle="tooltip" data-placement="top" title="Rejeitar"></a></td>
                                    <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="top" title="Aceitar"></a></td>
                                    <td><a a href="#" data-toggle="modal" data-target="#reagendarMarcacao"><i class="fa fa-calendar" data-toggle="tooltip" data-placement="top" title="Reagendar" ></i></a></td>
                                </tr>
                                <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                                    <td><a href="#" class="fa fa-remove" data-toggle="tooltip" data-placement="top" title="Rejeitar"></a></td>
                                    <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="top" title="Aceitar"></a></td>
                                    <td><a a href="#" data-toggle="modal" data-target="#reagendarMarcacao"><i class="fa fa-calendar" data-toggle="tooltip" data-placement="top" title="Reagendar" ></i></a></td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <h5>Ceites/Rejeitas</h5>
                         <table class="table table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th>Categoria</th>
                                    <th>Serviço</th>
                                    <th>Profissional</th>
                                    <th>Data</th>
                                    <th>Hora</th>
                                    <th>Estao</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                                    <td><strong>Aceite</strong></td>
                                </tr>
                                 <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                                    <td><strong>Rejeitada</strong></td>
                                </tr>
                            </tbody>
                        </table>
                        <!-- fim k_change -->
                        <br>
                       
                    </div>
                    <div class="modal-footer" style="background: #eee">
                        <a href="#" class="btn btn-primary">Aceitar Marcação</a>
                        <a href="#" class="btn btn-default" data-dismiss="modal">Cancelar</a>
                    </div>
              </div>

            </div>
        </div> 

        <!-- k_change -->

        
        <div id="reagendarMarcacao" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <div class="row">
                      <div class="col-md-10">
                          <h3 class="modal-title">Reagendamento de Marcação</h3>
                      </div>
                     
                  </div>
                </div>
                  <div class="modal-body">
                    
                        <table class="table table-bordered table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th>Categoria</th>
                                    <th>Serviço</th>
                                    <th>Profissional</th>
                                    <th>Data</th>
                                    <th>Hora</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Estetica</td>
                                    <td>Manicure</td>
                                    <td>José Luis</td>
                                    <td>12-10-2017</td>
                                    <td>12:00</td>
                               </tr>
                            </tbody>
                        </table>
                        
                        <br>
                        <form method="post">
                            <table class="table">
                                <tr>
                                    <td><label>Nova Data</label></td>
                                    <td><input type="date" id="data" readonly="" name="data" placeholder="dd-mm-aaaa" class="form-control"></td>
                                    <td><label>Nova Hora</label></td>
                                    <td>
                                         <select class="form-control">
                                            <option value="">9:30</option>
                                            <option value="">11:00</option>
                                        </select>
                                    </td>
                                    <td>
                                        <button type="submit" class="btn btn-success">Reagendar</button>
                                    </td>
                                </tr>
                            </table>
                            
                           
                        </form>
                        </div>
                    <div class="modal-footer" style="background: #eee">
                        <div class="alert alert-warning text-center" >alguma sms</div>
                    </div>
              </div>

            </div>
        </div> 
        <!-- fim k_change -->

        <script src="../../content/js/jquery.quicksearch.js"></script>
        <script>
            $("[type='search']").quicksearch('.table tbody tr');
        </script>
        
        
        <!-- k_change -->
            <script>
                $("[name='data']").datepicker({
                   dateFormat:"yy-mm-dd",
                   dayNames: ["Domingo", "Segunda-Feira", "Terça-Feira", "Quarta-Feira", "Quinta-Feira", "Sexta-Feira", "Sabado"],
                   dayNamesMin: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab" ],
                   monthNames: [ "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" ],
                   navigationAsDateFormat: true,
                   nextText: "Seguinte",
                   prevText: "Ant",
                   changeMonth: true,
                   changeYear: true
                });

           </script>
        <!-- fim k_change -->
    </body>
    
</html>
