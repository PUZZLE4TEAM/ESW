<?php $page = 'servico'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            <p>&nbsp;</p>
            <a name="top"></a>
            <article id="addProfissional">
                <form method="post">
                    <h3><strong><span class="glyphicon glyphicon-th-list"></span> Registro de Serviço</strong></h3>
                    <br>
                    <div class="row">
                        <div class="col-md-2"><h4>Serviço</h4></div>
                        <div class="col-md-4"><input type="text" name="servico" class="form-control"></div>
                        <div class="col-md-2"><h4>Categoria</h4></div>
                        <div class="col-md-4">
                            <select name="categoria" class="form-control">
                                <option value="" disabled="" selected="">Selecione a Categoria</option>
                                <option value="1">Cabelo</option>
                                <option value="1">Estetica</option>
                                <option value="1">Cabelo</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-2"><h4>Preço</h4></div>
                        <div class="col-md-4"><input type="text" name="telefone" class="form-control"></div>
                        <div class="col-md-6">
                            <!-- change -->
                            <input type="button" name="registrar" value="Efectuar Registrar Serviço" class="btn btn-primary" data-toggle="modal" data-target="#modalSMS">
                            <!-- /change -->
                            <button class="btn btn-default" id="btnCancelarAddProfissional">Cancelar Registro</button>
                        </div>                                                       
                    </div>
                     
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                             </div>
                        
                    </div>
                </form>
            </article>
            
            <article id="editProfissional">
                <form method="post">
                    <h3><strong><span class="glyphicon glyphicon-th-list"></span> Actualização de Serviço</strong></h3>
                    <br>
                    <div class="row">
                        <div class="col-md-2"><h4>Serviço</h4></div>
                        <div class="col-md-4"><input value="Manicure" type="text" name="servico" class="form-control"></div>
                        <div class="col-md-2"><h4>Categoria</h4></div>
                        <div class="col-md-4">
                            <select name="categoria" class="form-control">
                                <option value="1">Cabelo</option>
                                <option value="1" selected="">Estetica</option>
                                <option value="1">Cabelo</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-2"><h4>Preço</h4></div>
                        <div class="col-md-4"><input value="1234" type="text" name="telefone" class="form-control"></div>
                        <div class="col-md-6">
                            <!-- change -->
                            <input type="button" name="actualizar" value="Efectuar Actualização Serviço" class="btn btn-primary" data-toggle="modal" data-target="#modalSMS">
                            <!-- /change -->
                            <button class="btn btn-default" id="btnCancelarAddProfissional">Cancelar Registro</button>
                        </div>                                                       
                    </div>
                     
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                        </div>
                        
                    </div>
                </form>
            </article>
            
            <p>&nbsp;</p>
            <form method="post">
                <div class="form-group" id="search">
                    <div class="input-group">
                        <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                        <input type="search" name="filtro" placeholder="Faça uma Busca Aqui" class="form-control">
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-3">
                    <a href="#" id="btnAddProfissional"><span class="glyphicon glyphicon-plus-sign"></span> Adicionar Serviço</a>
                </div>
                
            </div> 
            <br>

            <table id="pes" class="table table-bordered table-hover table-responsive table-striped text-center" id="tblMarcacao">
                <thead>
                    <tr>
                        <th class="text-center">Serviço</th>
                        <th class="text-center">Categoria</th>                        
                        <th class="text-center">Preço</th>                        
                        <th class="text-center" colspan="2">Acção</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i=0; $i < 10; $i++):?>
                    <tr>
                        <td>Manicure</td>
                        <td>Estética</td>
                        <td>6723</td>
                        <td data-toggle="tooltip" data-placement="left" title="Actualizar"><a href="#top" class="btnEditProfissional"><i class="glyphicon glyphicon-edit"></i></a></td>                                    
                        <td data-toggle="tooltip" data-placement="left" title="Remover"><a href="#" data-toggle="modal" data-target="#modalConfirmar"><i class="fa fa-remove" ></i></a></td>            
                    </tr>
                    <?php endfor;?>
                    <tr>
                        <td>Pedicure</td>
                        <td>Estética</td>
                        <td>6723</td>
                        <td data-toggle="tooltip" data-placement="left" title="Actualizar"><a href="#top" class="btnEditProfissional"><i class="glyphicon glyphicon-edit"></i></a></td>                                    
                        <td data-toggle="tooltip" data-placement="left" title="Remover"><a href="#" data-toggle="modal" data-target="#modalConfirmar"><i class="fa fa-remove" ></i></a></td>            
                    </tr>
                </tbody>
            </table>
        </main>
        
          
        <?php include 'modalConfirmar.php';?>
        <!-- channge ->
        <?php include 'modalSMS.php';?>
        <!-- /change -->
        <script src="../../content/js/jquery.quicksearch.js"></script>
        <script>
            $("#btnAddProfissional").on("click",function(){
               $("#addProfissional").slideToggle(1000);
               $("#editProfissional").hide(0);
            });
            $(".btnEditProfissional").on("click",function(){
               $("#editProfissional").slideDown(1000);
               $("#addProfissional").hide(0);
            });
            $("#btnCancelarAddProfissional").on("click",function(){
                 $("#addProfissional").fadeOut(1000);
                 $("#editProfissional").fadeOut(1000);
            });

            $("[type='search']").quicksearch('.table tbody tr');
        </script>
    </body>
</html>
