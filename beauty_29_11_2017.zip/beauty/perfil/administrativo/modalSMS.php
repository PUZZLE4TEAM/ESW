<!-- Novo Arquivo -->

<div id="modalSMS" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>Mensagem</h4>
        </div>
            <div class="modal-body">
                <h4 class="alert alert-warning text-center"><span class="glyphicon glyphicon-exclamation-sign"></span> colocar aqui algum warnning</h4>           
                <h4 class="alert alert-success text-center"><span class="glyphicon glyphicon-ok"></span> colocar aqui algum sucess</h4>           
            </div>
            
      </div>

    </div>
</div> 