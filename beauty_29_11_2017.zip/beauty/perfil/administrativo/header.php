<!DOCTYPE HTML>
<html lang="pt">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="../../content/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/css/administrativo.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/fonts/font-awesome/css/font-awesome.css"  rel="stylesheet">
        <!-- k_change -->
        <link href="../../content/css/jquery-ui.css" rel="stylesheet" type="text/css"/>
      
        <script src="../../content/js/jquery-3-1-1.js" type="text/javascript"></script>
        <script src="../../content/js/jquery-ui.js" type="text/javascript"></script>
        <script src="../../content/js/jquery.mask.min.js" type="text/javascript"></script>
        <!-- fim k_change -->
        <script src="../../content/bootstrap-3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
        <title>Beauty</title>
    </head>
    <body>
        
        <header>
            <h2>Beauty</h2>
            
            <div id="user"><a href="perfil.php"><i class="glyphicon glyphicon-user"></i>  admin</a></div>
        </header>
        <nav>
            <div class="row">
                <div class="col-md-2 col-sm-2">
                    <a href="index.php" <?php if($page=='index') echo "class='activo'"; ?> ><!-- n_change -->
                        <span class="glyphicon glyphicon-home"></span>
                        <h5>Home</h5>
                    </a>
                </div>
                <div class="col-md-2 col-sm-2">
                    <a href="marcacao.php"  <?php if($page=='marcacao') echo "class='activo'"; ?>><!-- n_change -->
                        <span class="glyphicon glyphicon-time"></span>
                        <h5>Solicitude de Marcações</h5>
                    </a>
                </div>
                <div class="col-md-2 col-sm-2">
                    <a href="profissional.php"  <?php if($page=='profissional') echo "class='activo'"; ?> ><!-- n_change -->
                        <span class="glyphicon glyphicon-user"></span>
                        <h5>Profissionais</h5>
                    </a>
                </div>
                <div class="col-md-2 col-sm-2">
                    <a href="servico.php"  <?php if($page=='servico') echo "class='activo'"; ?> > <!-- n_change -->
                        <span class="glyphicon glyphicon-th"></span>
                        <h5>Serviços</h5>
                    </a>
                </div>
                <div class="col-md-2 col-sm-2">
                    <a href="agendaMensal.php"  <?php if($page=='agenda') echo "class='activo'"; ?> ><!-- n_change -->
                        <span class="glyphicon glyphicon-calendar"></span>
                        <h5>Agenda Mensal</h5>
                    </a>
                </div>
                <div class="col-md-2 col-sm-2">
                    <a href="relatorio.php"  <?php if($page=='relatorio') echo "class='activo'"; ?> > <!-- n_change -->
                        <span class="glyphicon glyphicon-stats"></span>
                        <h5>Relatório Estatístico</h5>
                    </a>
                </div>
            </div>
                
        </nav>