<?php $page = 'profissional'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            <p>&nbsp;</p>
            <a name="top"></a>
            <article id="addProfissional">
                <form method="post">
                    <h3><strong><span class="fa fa-user-circle"></span> Registro de Profissional</strong></h3>
                    <br>
                    <div class="row">
                        <div class="col-md-2"><h4>Nome Completo</h4></div>
                        <div class="col-md-4"><input type="text" name="nome" class="form-control"></div>
                        <div class="col-md-2"><h4>Categoria</h4></div>
                        <div class="col-md-4">
                            <select name="categoria" class="form-control">
                                <option value="" disabled="" selected="">Selecione a Categoria</option>
                                <option value="1">Cabelo</option>
                                <option value="1">Estetica</option>
                                <option value="1">Cabelo</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-2"><h4>Telefone</h4></div>
                        <div class="col-md-4"><input type="text" name="telefone" class="form-control"></div>
                        <div class="col-md-2"><h4>E-mail</h4></div>
                        <div class="col-md-4"><input type="email" name="email" class="form-control"></div>                               
                    </div>
                     <div class="row">
                        <div class="col-md-2"><h4>Horario</h4></div>
                       <div class="col-md-10">
                           <?php for($i=0; $i < 18; $i++): ?>
                           <code>
                               <input type="checkbox" name="horario" value="9h00"> 9h00
                           </code>
                           <?php endfor; ?>
                        </div>
                     </div>
                    <br>
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <!-- change -->
                            <input type="button" name="registrar" value="Registrar Profissional" class="btn btn-primary" data-toggle="modal" data-target="#modalSMS">
                            <!-- /change -->
                            <button class="btn btn-default" id="btnCancelarAddProfissional">Cancelar Registro</button>
                        </div>
                        
                    </div>
                </form>
            </article>
            
            <article id="editProfissional">
                <form method="post">
                    <h3><strong><span class="fa fa-user-circle"></span> Actualização de Profissional</strong></h3>
                    <br>
                    <div class="row">
                        <div class="col-md-2"><h4>Nome Completo</h4></div>
                        <div class="col-md-4"><input type="text" name="nome" value="Antonio Cassinda" class="form-control"></div>
                        <div class="col-md-2"><h4>Categoria</h4></div>
                        <div class="col-md-4">
                            <select name="categoria" class="form-control">
                                <option value="1">Cabelo</option>
                                <option value="1" selected="">Estetica</option>
                                <option value="1">Cabelo</option>
                            </select>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-2"><h4>Telefone</h4></div>
                        <div class="col-md-4"><input type="text" value="+244 924 123 431" name="telefone" class="form-control"></div>
                        <div class="col-md-2"><h4>E-mail</h4></div>
                        <div class="col-md-4"><input type="email" value="antonio.cassinda@gmail.com" name="email" class="form-control"></div>                               
                    </div>
                     <div class="row">
                        <div class="col-md-2"><h4>Horario</h4></div>
                       <div class="col-md-10">
                           <?php for($i=0; $i < 18; $i++): ?>
                           <code>
                               <input type="checkbox" name="horario" value="9h00" > 9h00
                           </code>
                           <?php endfor; ?>
                        </div>
                     </div>
                    <br>
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <!-- change -->
                            <input type="button" name="actualizar" value="Actualizar Profissional" class="btn btn-info" data-toggle="modal" data-target="#modalSMS">
                            <!-- /change -->
                            <button class="btn btn-default" id="btnCancelarAddProfissional">Cancelar Actualização</button>
                        </div>
                        
                    </div>
                </form>
            </article>
            
            <p>&nbsp;</p>
            <form method="post">
                <div class="form-group" id="search">
                    <div class="input-group">
                        <div class="input-group-addon"><span class="glyphicon glyphicon-search"></span></div>
                        <input type="search" name="filtro" placeholder="Faça uma Busca Aqui" class="form-control">
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-md-3">
                    <a href="#" id="btnAddProfissional"><span class="glyphicon glyphicon-plus-sign"></span> Adicionar Profissional</a>
                </div>
                <div class="col-md-8">
                    <strong class="badge">40</strong> Profissionais Adicionados
                </div>
            </div>
                        <br>

            <table class="table table-bordered table-hover table-responsive table-striped text-center" id="tblMarcacao">
                <thead>
                    <tr>
                        <th class="text-center">Nome</th>
                        <th class="text-center">Categoria</th>                        
                        <th class="text-center">E-mail</th>
                        <th class="text-center">Telefone</th>
                        <th class="text-center">Horario(s)</th>                        
                        <th class="text-center" colspan="2">Acção</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i=0; $i < 10; $i++):?>
                    <tr>
                        <td>Inês Martins</td>
                        <td>Estética</td>
                        <td>ines.martins@gov.co.ao</td>
                        <td>+244 923 234 123</td>
                        <td data-toggle="tooltip" data-placement="left" title="Ver Horarios" ><a href="#" data-toggle="modal" data-target="#modalHorario" id="linkHorario"><i class="glyphicon glyphicon-time"></i></a></td>                        
                        <td data-toggle="tooltip" data-placement="left" title="Actualizar"><a href="#top" class="btnEditProfissional"><i class="glyphicon glyphicon-edit"></i></a></td>                                    
                        <td data-toggle="tooltip" data-placement="left" title="Remover"><a href="#" data-toggle="modal" data-target="#modalConfirmar"><i class="fa fa-remove" ></i></a></td>            
                    </tr>
                    <?php endfor;?>
                </tbody>
            </table>
        </main>
        
        
        <!-- Modal para visualizar os Horarios do Profissional-->
        <div id="modalHorario" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4>Grelha de Horario</h4>
                </div>
                <div class="modal-body">
                    <div id="myModal-body">
                        <code>09h00</code>
                        <code>09h30</code>
                        <code>18h00</code>
                        <code>18h30</code>
                        <code>19h00</code>
                        <code>19h30</code>
                        <code>18h00</code>
                        <code>18h30</code>                    
                        <code>19h00</code>
                        <code>19h30</code>
                    </div>
                </div>
                <div class="modal-footer" style="background: #eee">
                    <a href="#" class="btn btn-default" data-dismiss="modal">Sair</a>
                </div>
              </div>

            </div>
        </div>    
        <?php include 'modalConfirmar.php';?>
        <!-- channge ->
        <?php include 'modalSMS.php';?>
        <!-- /change -->
        <script>
            $("#btnAddProfissional").on("click",function(){
               $("#addProfissional").slideToggle(1000);
               $("#editProfissional").hide(0);
            });
            $(".btnEditProfissional").on("click",function(){
               $("#editProfissional").slideDown(1000);
               $("#addProfissional").hide(0);
            });
            $("#btnCancelarAddProfissional").on("click",function(){
                 $("#addProfissional").fadeOut(1000);
                 $("#editProfissional").fadeOut(1000);
            });
        </script>
        <script src="../../content/js/jquery.quicksearch.js"></script>
        <script>
            $("[type='search']").quicksearch('.table tbody tr');
        </script>
    </body>
</html>
