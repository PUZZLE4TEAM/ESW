<?php $page = 'index'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            
            <h1 id="wellcome">WellCome</h1>
            <h5 class="text-center">bem-vindo à maior rede de salão de beleza online - beauty</h5>
        </main>
        
        
        
    </body>
</html>
