<?php $page = 'relatorio'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            <p>&nbsp;</p>
            <div class="row">
                <div class="col-md-3">
                    <div class="dash" id="cliente">
                        <h1><i class="fa fa-user-o"></i> <small>120</small></h1>
                        <h5>Clientes Registrados</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dash" id="servico">
                        <h1><i class="fa fa-th"></i> <small>30</small></h1>
                        <h5>Serviços Disponiveis</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dash" id="marcacao">
                        <h1><i class="fa fa-calendar-o"></i> <small>120</small></h1>
                        <h5>Marcações Solicitadas</h5>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dash" id="profissional">
                        <h1><i class="fa fa-user-circle"></i> <small>15</small></h1>
                        <h5>Profissionais Registrados</h5>
                    </div>
                </div>
                
                
            </div>
            
            
             <article class="dashBoard" id="dashCliente">
                 <div class="row">
                     <div class="col-md-4">
                         <div id="container" style="height: 290px;"></div>
                     </div>
                     <div class="col-md-8">
                         <h1><small>total de </small>120</h1>
                         <div class="row">
                             <div class="col-md-4">
                                 <h3><strong>30</strong> activos</h3>
                             </div>
                              <div class="col-md-4">
                                 <h3><strong>30</strong> Bloqueados</h3>
                             </div>
                              <div class="col-md-4">
                                 <h3><strong>30</strong> Esperando</h3>
                             </div>
                         </div>
                         <div class="row">
                             <h4 class="text-left">Clientes com maior solicitação</h4>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5>30 solicitações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5>30 solicitações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5>30 solicitações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-users"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">Outros</h5>
                                        <h5>30 solicitações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                         </div>
                     </div>
                 </div>
             </article>
            
            
             <article class="dashBoard" id="dashServico">
                <h2>20 <small>serviços</small></h2>
                
                <div class="row">
                    <div class="col-md-4">
                        <h3>Manicure <small>12 solicatações</small></h3>
                    </div>
                    <div class="col-md-4">
                        <h3>Pedicure <small>2 solicatações</small></h3>
                    </div>
                    <div class="col-md-4">
                        <h3>Breche <small>1 solicatações</small></h3>
                    </div>
                </div>   
                <p>&nbsp;</p>
                <div class="row">
                     <div class="col-md-12">
                         <table class="table table-hover table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">Serviço</th>
                                    <th class="text-center">Preço</th>
                                    <th class="text-center">Categoria</th>
                                    <th class="text-center">Solicitações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Manicure</td>
                                    <td>2000,00</td>
                                    <td>Estetica</td>
                                    <td>10</td>
                                </tr>
                                 <tr>
                                    <td>Manicure</td>
                                    <td>2000,00</td>
                                    <td>Estetica</td>
                                    <td>10</td>
                                </tr>
                                 <tr>
                                    <td>Manicure</td>
                                    <td>2000,00</td>
                                    <td>Estetica</td>
                                    <td>10</td>
                                </tr>
                                 <tr>
                                    <td>Manicure</td>
                                    <td>2000,00</td>
                                    <td>Estetica</td>
                                    <td>10</td>
                                </tr>
                                 <tr>
                                    <td>Manicure</td>
                                    <td>2000,00</td>
                                    <td>Estetica</td>
                                    <td>10</td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                 </div>
             </article>
            
            
              <article class="dashBoard" id="dashMarcacao">
                    <div id="containerMarcacao" style="height: 290px;"></div>
                    <p>&nbsp;</p>
                    <div class="row">
                        <div class="col-md-3">
                            <h2>30 <small>marcações</small></h2>
                        </div>
                        <div class="col-md-3">
                            <h2>10 <small>aceites</small></h2>
                        </div>
                        <div class="col-md-3">
                            <h2>15 <small>negados</small></h2>
                        </div>
                        <div class="col-md-3">
                            <h2>5 <small>espera</small></h2>
                        </div>
                    </div>
             </article>
            
             <article class="dashBoard" id="dashProfissional">
                 <div class="row">
                    
                     <div class="col-md-12">
                         <h1><small>total de </small>120</h1>
                         
                         <div class="row">
                             <h4 class="text-left">&nbsp; &nbsp;&nbsp;Profissional com maior marcações atendidas</h4>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5 class="text-left">30 marcações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5 class="text-left">30 marcações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-user-circle-o"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">José Martins</h5>
                                        <h5 class="text-left">30 marcações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                             <div class="col-md-3">
                                 <div class="row">
                                     <div class="col-md-4"><h1 class="text-left"><i class="fa fa-users"></i></h1></div>
                                     <div class="col-md-8">
                                         <br>
                                        <h5 class="text-left">Outros</h5>
                                        <h5 class="text-left">30 marcações</h5>
                                     </div>
                                 </div>                                 
                             </div>
                         </div>
                     </div>
                 </div>
             </article>
             <p>&nbsp;</p>
        </main>
<script src="../../content/js/highcharts.js"></script>
<script src="../../content/js/exporting.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        
        $("#marcacao").on("click",function(){
            $("#dashCliente").hide();
            $("#dashProfissional").hide(); 
            $("#dashServico").hide(); 
            $("#dashMarcacao").fadeToggle(1000);
        });
        $("#cliente").on("click",function(){
            $("#dashCliente").fadeToggle(1000);
            $("#dashMarcacao").hide();
            $("#dashServico").hide();
            $("#dashProfissional").hide(); 
        });
        $("#profissional").on("click",function(){
            $("#dashCliente").hide();
            $("#dashMarcacao").hide();
            $("#dashServico").hide();
            $("#dashProfissional").fadeToggle(1000); 
        });
        $("#servico").on("click",function(){
            $("#dashCliente").hide();
            $("#dashMarcacao").hide();
            $("#dashProfissional").hide();             
            $("#dashServico").fadeToggle(1000);
        });
        
        
        //Grafico Circular dos Clientes
        Highcharts.chart('container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Dados Gerais de Clientes'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Brands',
                colorByPoint: true,
                data: [{
                    name: 'Activos',
                    y: <?php echo 20;?>,
                    selected: true,
                    sliced: true,                    

                }, {
                    name: 'Bloqueados',
                    y: <?php echo 50;?>,
                }, {
                    name: 'Espera',
                    y: <?php echo 5;?>
                }]
            }]
        });
    });
    
    //Grafico de Barra para as Marcações
    
    // Create the chart
Highcharts.chart('containerMarcacao', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Horarios x Número de Marcações'
    },
    subtitle: {
        text: 'Horarios com os seus respectivos números de marcação'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Número de Marcação'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.1f}%'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },

    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: '09h00',
            y: <?php echo 30;?>,
            drilldown: '09h00'
        }, {
            name: '09h30',
            y: 30,
            drilldown: '09h30'
        }, {
            name: '10h00',
            y: 30,
            drilldown: '10h00'
        }, {
            name: '10h30',
            y: 30,
            drilldown: '10h30'
        }, {
            name: '11h00',
            y: 30,
            drilldown: '11h00'
        }, {
            name: '11h30',
            y: 30,
            drilldown: '11h30'
        }, {
            name: '14h00',
            y: 30,
            drilldown: '14h00'
        }, {
            name: '14h30',
            y: 30,
            drilldown: '14h30'
        }, {
            name: '15h00',
            y: 30,
            drilldown: '15h00'
        }, {
            name: '15h30',
            y: 30,
            drilldown: '15h30'
        }, {
            name: '16h00',
            y: 30,
            drilldown: '16h00'
        }, {
            name: '16h30',
            y: 30,
            drilldown: '16h30'
        }, {
            name: '17h00',
            y: 4,
            drilldown: '17h00'
        }, {
            name: '17h30',
            y: 70,
            drilldown: '17h30'
        }, {
            name: '18h00',
            y: 1,
            drilldown: '18h00'
        }, {
            name: '18h30',
            y: 3,
            drilldown: '18h30'
        }, {
            name: '19h00',
            y: 20,
            drilldown: '19h00'
        }, {
            name: '19h30',
            y: 10,
            drilldown: '19h30'
        }]
    }],
   
});
</script>        
    </body>
</html>
