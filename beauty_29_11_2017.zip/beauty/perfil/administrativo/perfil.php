<?php $page = 'perfil'; ?> <!-- n_change -->

<?php include 'header.php'; ?>
        <main class="container">
            <p>&nbsp;</p>
            <article class="panel panel-danger">
                <div class=" panel-heading">
                    <h4 class="panel-title">
                        <a href="#" data-toggle="collapse" data-target="#painelCredenciais"><i class="fa fa-lock"></i> Dados de Credenciais</a>
                    </h4>
                </div>
                <form method="post">
                <div  id="painelCredenciais"  class="collapse">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">Nome do Usuário</div>
                            <div class="col-md-8">
                                <input type="text" name="nomeUsuario" value="joshua.capita" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-4">Palavra-Passe (Actual)</div>
                            <div class="col-md-8">
                                <input type="password" name="passeActual" value="joshua.capita@gmail.com" class="form-control">
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">Palavra-Passe (Nova)</div>
                            <div class="col-md-8">
                                <input type="password" name="passeNova" value="joshua.capita@gmail.com" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-4">Palavra-Passe (Confirmada)</div>
                            <div class="col-md-8">
                                <input type="password" name="passeConfirmada" value="joshua.capita@gmail.com" class="form-control">
                            </div>
                        </div>
                   
                </div>
                    <div class=" panel-footer">
                        <!-- change -->
                        <input type="button" value="Alterar Credenciais" name="alterar" class="btn btn-info" data-toggle="modal" data-target="#modalSMS">
                        <!-- /change -->
                    </div>
                </div>
              </form>
            </article>
            
            <!-- change here: mudei os nomes das inputs, os types e os values -->
            
            <article class="panel panel-warning">
                <div class=" panel-heading">
                    <h4 class="panel-title">
                        <a href="#" data-toggle="collapse" data-target="#painelPessoal"><i class="fa fa-user-circle-o"></i> Dados de Pessoais</a>
                    </h4>
                </div>
                <form method="post">
                <div  id="painelPessoal"  class="collapse">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">Nome Completo</div>
                            <div class="col-md-8">
                                <input type="text" name="nomeCompleto" value="Josue Capita" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-4">E-mail</div>
                            <div class="col-md-8">
                               <input type="email" name="email" value="joshua.capita@gmail.com" class="form-control">
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-4">Telefone</div>
                            <div class="col-md-8">
                                <input type="number" name="telefone" value="992 456 123" class="form-control">
                            </div>
                        </div>
                        
                </div>
                    <div class=" panel-footer">
                        <!-- change -->
                        <input type="button" value="Alterar Dados Pessoais" name="alterarDadosPessoais" class="btn btn-info" data-toggle="modal" data-target="#modalSMS">
                        <!-- change -->
                    </div>
                </div>
              </form>
            </article>
            <!-- fim change -->
        </main>    
        <!-- channge ->
        <?php include 'modalSMS.php';?>
        <!-- /change -->
    </body>
</html>
