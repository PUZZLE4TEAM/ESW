
<div id="modalConfirmar" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>Confirmação de Remoção</h4>
        </div>
            <div class="modal-body">
                <h4 class="alert alert-warning text-center"><strong>Aviso: </strong> Tem a certeza que deseja remover?</h4>           

            </div>
            <div class="modal-footer" style="background: #eee">
                <a href="#" class="btn btn-info">SIM</a>
                <a href="#" class="btn btn-default" data-dismiss="modal">NÃO</a>
            </div>
      </div>

    </div>
</div> 