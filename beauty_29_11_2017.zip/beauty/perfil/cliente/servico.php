<!-- k_change -->
<?php $page = 'servico'; ?>
<!-- fim k_change --> 
<?php include 'header.php'; ?>         
        
        
        <main class="container">
            <p>&nbsp;</p><p>&nbsp;</p>
            
            <h3>Categoria: <strong>Cabelo</strong></h3>
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="service">
                        <div class="row">
                            <div class="col-md-12"> <img src="../../content/img/barba.jpg" alt=""/>  </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12"> <h3>Corte de Barba</h3></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-sm-2"><strong>Preço: </div>
                            <div class="col-md-6 col-sm-6"><span class="price">5.900AKz</span></div>
                            <div class="col-md-4 col-sm-4"><h5><a href="#"><i class="fa fa-plus-square-o"></i> solicitar</a></h5></div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="service">
                        <div class="row">
                            <div class="col-md-12"> <img src="../../content/img/sobrancelas.jpg" alt=""/>  </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12"> <h3>Corte de Barba</h3></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-sm-2"><strong>Preço: </div>
                            <div class="col-md-6 col-sm-6"><span class="price">5.900AKz</span></div>
                            <div class="col-md-4 col-sm-4"><h5><a href="#"><i class="fa fa-plus-square-o"></i> solicitar</a></h5></div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="service">
                        <div class="row">
                            <div class="col-md-12"> <img src="../../content/img/images.jpeg" alt=""/>  </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12"> <h3>Corte de Barba</h3></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 col-sm-2"><strong>Preço: </div>
                            <div class="col-md-6 col-sm-6"><span class="price">5.900AKz</span></div>
                            <div class="col-md-4 col-sm-4"><h5><a href="#"><i class="fa fa-plus-square-o"></i> solicitar</a></h5></div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </main>
       
<?php include 'footer.php'; ?>