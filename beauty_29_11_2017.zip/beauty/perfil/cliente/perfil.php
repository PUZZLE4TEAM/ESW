<!-- k_change -->
<?php $page = 'perfil'; ?>
<!-- fim k_change --> 
<?php include 'header.php'; ?>
        <!-- change -->   
        
            <div class="row">
                
                 <div class="col-md-8 col-md-offset-2">
                     <p>&nbsp;</p>
                     <p>&nbsp;</p>
                     <article class="panel panel-danger">
                        <div class=" panel-heading">
                            <h4 class="panel-title">
                                <a href="#" data-toggle="collapse" data-target="#painelCredenciais"><i class="fa fa-lock"></i> Dados de Credenciais</a>
                            </h4>
                        </div>
                        <form method="post">
                        <div  id="painelCredenciais"  class="collapse">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">Nome do Usuário</div>
                                    <div class="col-md-8">
                                        <input type="text" name="nomeUsuario" value="joshua.capita" class="form-control">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-4">Palavra-Passe (Actual)</div>
                                    <div class="col-md-8">
                                        <input type="password" name="passeActual" value="joshua.capita@gmail.com" class="form-control">
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-4">Palavra-Passe (Nova)</div>
                                    <div class="col-md-8">
                                        <input type="password" name="passeNova" value="joshua.capita@gmail.com" class="form-control">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-4">Palavra-Passe (Confirmada)</div>
                                    <div class="col-md-8">
                                        <input type="password" name="passeConfirmada" value="joshua.capita@gmail.com" class="form-control">
                                    </div>
                                </div>

                        </div>
                            <div class=" panel-footer">
                                <input type="button" value="Alterar Credenciais" name="alterar" class="btn btn-info" data-toggle="modal" data-target="#modalSMS">
                            </div>
                        </div>
                      </form>
                    </article>


                    <article class="panel panel-warning">
                        <div class=" panel-heading">
                            <h4 class="panel-title">
                                <a href="#" data-toggle="collapse" data-target="#painelPessoal"><i class="fa fa-user-circle-o"></i> Dados de Pessoais</a>
                            </h4>
                        </div>
                        <form method="post">
                        <div  id="painelPessoal"  class="collapse">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">Nome Completo</div>
                                    <div class="col-md-8">
                                        <input type="text" name="nomeCompleto" value="Josue Capita" class="form-control">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-4">E-mail</div>
                                    <div class="col-md-8">
                                       <input type="email" name="email" value="joshua.capita@gmail.com" class="form-control">
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-4">Telefone</div>
                                    <div class="col-md-8">
                                        <input type="text" name="telefone" class="form-control">
                                    </div>
                                </div>

                        </div>
                            <div class=" panel-footer">
                                <input type="button" value="Alterar Dados Pessoais" name="alterarDadosPessoais" class="btn btn-info" data-toggle="modal" data-target="#modalSMS">
                            </div>
                        </div>
                      </form>
                    </article>
                   
                </div>
            </div>
        
        <!-- channge ->
        <?php include '../administrativo/modalSMS.php';?>
        <!-- /change -->
       
       <!-- fim change -->
<?php include 'footer.php';?>