<!DOCTYPE HTML>
<html lang="pt">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="../../content/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/css/cliente.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/fonts/font-awesome/css/font-awesome.css" rel="stylesheet"/>
        <!-- change -->
        <link href="../../content/css/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <!-- /change -->
        <script src="../../content/js/jquery-3-1-1.js" type="text/javascript"></script>
        <!-- change -->
        <script src="../../content/js/jquery-ui.js" type="text/javascript"></script>
        <script src="../../content/js/jquery.mask.min.js" type="text/javascript"></script>
        <!-- change -->
        <script src="../../content/bootstrap-3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
        <title>Beauty</title>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
                <div class="navbar-header">

                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>

                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-left" style="margin-left: 30%;">
                        <li <?php if($page=='index') echo "class='active'"; ?> ><a href="index.php">HOME</a></li>
                        <!-- change -->
                        <li <?php if($page=='servico') echo "class='active'"; ?>><a href="servico.php">SERVIÇOS</a></li> 
                        <!-- /change -->
                        <li <?php if($page=='marcacao') echo "class='active'"; ?>><a href="marcacao.php">MARCAÇÕES</a></li>
                        <li <?php if($page=='perfil') echo "class='active'"; ?>><a href="perfil.php">PERFIL </a></li>   
                        <li><a href="#"></a></li>
                        <li><a href="#"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                    </ul>
                </div>
            </nav>
            
            <div class="row logo">
             
                <div class="col-md-1">
                    <img src="../../content/img/logo_hair.png" alt="" style="width: 90px"/>
                </div>
                <div class="col-md-8">
                    <h2>Beauty</h2>
                    <h5>A paixão pela sua beleza</h5>
                </div>
                <div class="col-md-2">
                    <a href="#contactos" >Contacte-nos</a>
                </div>
            </div>
            
        </header>