<!-- k_change -->
<?php $page = 'index'; ?>
<!-- fim k_change --> 
<?php include 'header.php'; ?>         
        <div class="row">
            <div class="col-md-12">
                <img src="../../content/img/header_cliente.png" id="imgBanner"/>
            </div>
        </div>   
        
        <main class="container" id="home">
            <div class="row">
                <div class="col-md-4">
                    <img src="../../content/img/service.png" class="center-block">
                    <h2 class="text-center">Nossos Serviços</h2>
                </div>
                <div class="col-md-4">
                    <img src="../../content/img/marcacao.png" class="center-block">
                    <h2 class="text-center">Suas Marcações</h2>
                </div>
                <div class="col-md-4">
                    <img src="../../content/img/perfil.png" class="center-block">
                    <h2 class="text-center">Seu Perfil</h2>
                </div>
            </div>
        </main>
       
<?php include 'footer.php'; ?>