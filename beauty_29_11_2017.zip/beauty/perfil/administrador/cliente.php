<?php $page = 'cliente'; ?> <!-- n_change -->
<?php include 'header.php'; ?>
                
        <main class="container">
            <p>&nbsp;</p> <!-- n_change -->
                <section class="col-md-12">
                    <ul class="nav nav-tabs">
                        <li role="presentation" class="active"><a href="#">Clientes em Espera</a></li>
                        <li role="presentation"><a href="#">Clientes Bloqueados</a></li>
                        <li role="presentation"><a href="#">Clientes Activos</a></li>
                    </ul>
                    <p>&nbsp;</p>
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>UserName</th>
                                <th>Nome Completo</th>
                                <th>E-mail</th>
                                <th>Telemóvel</th>
                                <th colspan="2">Opções</th>
                                <th><input type="checkbox" name="selectAll" class="form-control" value="selectAll" data-toggle="tooltip" data-placement="top" title="Selecionar Todos"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                for($i=0; $i < 3; $i++):
                            ?>
                            <tr>
                                <td>osvalhossi</td>
                                <td>Osvaldo Hossi</td>
                                <td>osvaldohossi@gmail.com</td>
                                <td>934 321 455</td>
                                <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="left" title="Bloquear"></a></td>
                                <td><a href="#" class="glyphicon glyphicon-lock" data-toggle="tooltip" data-placement="left" title="Bloquear" style="color: #f60"></a></td>
                                <td><input type="checkbox" name="selectAll" class="form-control" value="selectAll" data-toggle="tooltip" data-placement="top" title="Selecionar"></td>
                            </tr>
                            <tr>
                                <td>joseLuis</td>
                                <td>Jose Martins</td>
                                <td>joseluis@gmail.com</td>
                                <td>930 554 455</td>
                                <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="left" title="Bloquear"></a></td>
                                <td><a href="#" class="glyphicon glyphicon-lock" data-toggle="tooltip" data-placement="left" title="Bloquear" style="color: #f60"></a></td>
                                <td><input type="checkbox" name="selectAll" class="form-control" value="selectAll" data-toggle="tooltip" data-placement="top" title="Selecionar"></td>
                            </tr>
                            <tr>
                                <td>mac</td>
                                <td>Miguel Kissala</td>
                                <td>mac@gmail.com</td>
                                <td>934 321 123</td>
                                <td><a href="#" class="glyphicon glyphicon-ok" data-toggle="tooltip" data-placement="left" title="Bloquear"></a></td>
                                <td><a href="#" class="glyphicon glyphicon-lock" data-toggle="tooltip" data-placement="left" title="Bloquear" style="color: #f60"></a></td>
                                <td><input type="checkbox" name="selectAll" class="form-control" value="selectAll" data-toggle="tooltip" data-placement="top" title="Selecionar"></td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </section>
        </main>
                    
        
    </body>
</html>
