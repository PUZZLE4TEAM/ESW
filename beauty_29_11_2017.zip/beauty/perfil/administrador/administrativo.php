<?php $page = 'administrativo'; ?> <!-- n_change -->
<?php include 'header.php'; ?>
                
    <main class="container">
        <p>&nbsp;</p>
     <section class="col-md-12">
                    <ul class="nav nav-tabs">
                        <li role="presentation" class="active"><a href="#">Registrar Administrativo</a></li>
                        <li role="presentation"><a href="#">Visualizar Administrativo</a></li>
                    </ul>
                    <p>&nbsp;</p>
                    
                    <form class="form-horizontal" id="registroForm" method="post">
                        <fieldset>
                            <legend>Dados Pessoais</legend>
                             <div class="form-group">
                                 <div class="col-md-3">
                                     <label>Nome Completo</label>
                                 </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
                                        <input type="text" name="nomeCompleto" class="form-control"/>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-3">
                                    <label>E-mail</label>
                                </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon">@</div>
                                        <input type="email" name="email" class="form-control"/>
                                    </div>                            
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-3">
                                    <label>Telefone</label>
                                </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon">#</div>
                                        <input type="text" name="telefone" class="form-control"/>
                                    </div>                            
                                </div>
                            </div>
                        </fieldset>

                         <fieldset>
                            <legend>Dados de Acesso</legend>
                             <div class="form-group">
                                 <div class="col-md-3">
                                     <label>Nome do Usuário</label>
                                 </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></div>
                                        <input type="text" name="userName" class="form-control"/>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-3">
                                    <label>Palavra-Passe</label>
                                </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></div>
                                        <input type="password" name="palavraPasse" class="form-control"/>
                                    </div>                            
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-3">
                                    <label>Confirmação</label>
                                </div>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></div>
                                        <input type="password" name="palavraPasseConfirmada" class="form-control"/>
                                    </div>                            
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-info btn-lg" style="width: 100%;">Finalizar o Registro</button>
                        </fieldset>
                    </form>
                </section>
    </main>           
        
    </body>
</html>
