<!DOCTYPE HTML>
<html lang="pt">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="../../content/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/css/administrativo.css" rel="stylesheet" type="text/css"/>
        <link href="../../content/css/administrador.css" rel="stylesheet" type="text/css"/>      
        <link href="../../content/fonts/font-awesome/css/font-awesome.css"  rel="stylesheet">
        <script src="../../content/js/jquery-3-1-1.js" type="text/javascript"></script>
        <script src="../../content/bootstrap-3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
        <title>Beauty</title>
    </head>
    <body>
        
        <header>
            <h2>Beauty</h2>
            
            <div id="user"><a href="perfil.php"><i class="glyphicon glyphicon-user"></i>  admin</a></div>
        </header>
        <nav>
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <a href="index.php" <?php if($page=='index') echo "class='activo'"; ?>>
                        <span class="glyphicon glyphicon-home"></span>
                        <h5>Home</h5>
                    </a>
                </div>
               
                <div class="col-md-3 col-sm-3">
                    <a href="cliente.php" <?php if($page=='cliente') echo "class='activo'"; ?>>
                        <span class="glyphicon glyphicon-user"></span>
                        <h5>Clientes</h5>
                    </a>
                </div>
                
                <div class="col-md-3 col-sm-3">
                    <a href="administrativo.php" <?php if($page=='administrativo') echo "class='activo'"; ?>>
                        <span class="fa fa-user-circle-o" style="font-size: 2.4em;"></span>
                        <h5>Administrativo</h5>
                    </a>
                </div>
                <div class="col-md-3 col-sm-3">
                    <a href="administrativo.php">
                        <span class="glyphicon glyphicon-log-out" style="font-size: 2.4em;"></span>
                        <h5>Logout</h5>
                    </a>
                </div>
            </div>
                
        </nav>