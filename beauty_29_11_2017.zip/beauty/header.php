<!DOCTYPE HTML>
<html lang="pt">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="content/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="content/css/index.css" rel="stylesheet" type="text/css"/>
        <link href="content/fonts/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
        
        <script src="content/js/jquery-3-1-1.js" type="text/javascript"></script>
        <script src="content/bootstrap-3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
        <title>Beauty</title>
    </head>
    <body>
       <nav class="navbar navbar-default navbar-fixed-top">
            <div class="navbar-header">
                
              <a class="navbar-brand" href="index.php">
                  <img src="content/img/logo_hair_litle.png" />  Beauty
              </a>
               
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
                
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- k_change -->
                    <li <?php if($page=='index') echo "class='activo'"; ?>><a href="index.php">HOME</a></li>
                    <li <?php if($page=='servico') echo "class='activo'"; ?>><a href="servico.php">SERVIÇOS</a></li>
                    <li><a href="index.php#contactos">CONTACTOS </a></li>   
                    <li><a href="index.php#sobre">SOBRE</a></li> 
                    <li><a href="#"></a></li>
                    <li <?php if($page=='registro') echo "class='activo'"; ?>><a href="registro.php"><span class="glyphicon glyphicon-user"></span> Registrar</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#loginModal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <!-- fim k_change -->
                </ul>
                
            </div>
        </nav>