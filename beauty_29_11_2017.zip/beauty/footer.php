 <!-- Login Form -->
        <div id="loginModal" class="modal fade" role="dialog">
          <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="row">
                    <div class="col-md-10">
                        <h3 class="modal-title">Loga-se agora</h3>
                        <h5>insira as suas credenciais no formulário abaixo</h5>
                    </div>
                    <div class="col-md-2">
                        <img src="content/img/locked.png"/>
                    </div>
                </div>
              </div>
                <form id="loginForm" class="form-horizontal" method="post">
                    <div class="modal-body" style="background:#eee">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><span class="glyphicon glyphicon-user"></span></div>
                                    <input  class="form-control" type="text" name="userName" placeholder="Nome do Usuário" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></div>
                                    <input type="password" class="form-control" name="userPass" placeholder="Palavra-passe"/>
                                </div>
                            </div>
                        <!-- change -->
                        <h5>Se ainda não és um cliente registrado, <a href="registro.php">registra-se ja!</a></h5>
                        <!-- /change -->
                    </div>
                    <div class="modal-footer" style="background: #eee">
                      <button type="submit" class="btn btn-warning btn-lg">Entrar</button>
                    </div>
                </form>
            </div>

          </div>
        </div>        









        <footer class="container-fluid">
            <hr>
            <h5 class="text-center">Puzzle, &REG; Todos os direitos reservados</h5>
        </footer>
       
        <script type="text/javascript" src="content/jquery/jquery.validate.js"></script>
        <script type="text/javascript" src="content/jquery/validacoes.js"></script>
    </body>
</html>