<?php
    require 'phpmailer/PHPMailerAutoload.php';
	
    function enviarEmail(){

        $email = "miguelkissala10@gmail.com";                    
                    
        $message = "<!DOCTYPE HTML>
                    <html lang='pt'>
                        <head>
                            <meta charset='utf-8' />
                            <meta name='viewport' content='width=device-width, initial-scale=1' />
                            <title>angoHair</title>
                            <style>
                                body{
                                    background: #eee;
                                    font-family: arial;
                                }
                                main{
                                    float: left;
                                    width: 90%;
                                    margin-left: 5%;
                                    background: #eee;
                                    border-radius: 10px;
                                }
                                img{
                                    float: left; width: 100px;
                                }
                                h1{text-align: center; color:#f50}
                                p{
                                    float: left;
                                    width: 100%;
                                    padding: 10px;
                                    text-align: justify;
                                }
                                span{float: left; width: 100%; text-align: center; border-bottom: 1px solid #aaa; padding-bottom: 20px;}
                            </style>
                        </head>
                        <body>

                            <main>
                                <h1>Beauty</h1>
                                <span>A paixão pela sua beleza</span>

                                <p>
                                    Olá Sr(a), a sua conta aberta no nosso site, está pronta!
                                    Para acessar basta <a href='http://localhost/angoHair/' target='_blank'>clicar aqui</a> <br><br>

                                    Se voce não solicitou nenhum registro, ignore essa mensagem ou entre em contacto <a href='http://localhost/angoHair/index.php#sobre' target='_blank'>connosco</a>.

                                </p>
                                <p>
                                     Obrigado!
                                </p>
                            </main>

                        </body>
                    </html>
        ";
        
        $subject = "Puzzle Team";

        $mail = new PHPMailer;

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = 'tls';
        $mail->SMTPAuth = true;
        $mail->Username = "puzzleteam17@gmail.com";
        $mail->Password = "teamPuzzle17";
        $mail->setFrom('puzzleteam17@gmail.com', 'Beauty Salon');
        $mail->addReplyTo('miguelkissala10@gmail.com', 'Beauty Salon');
        $mail->addAddress($email);
        $mail->Subject = $subject;
        $mail->msgHTML($message);
        //$mail->AddAttachment($arquivo['tmp_name'], $arquivo['name']  );
        // $mail->AddAttachment("Relatorio.pdf");

        if (!$mail->send()) {
           $error = "Erro de Envio: " . $mail->ErrorInfo;
            ?><script>alert('<?php echo $error ?>');</script><?php
        } 
        else {
           echo "<script>alert('E-mail Enviado Com Sucesso para $email')</script>";
        }

    }
    
    enviarEmail();
?>