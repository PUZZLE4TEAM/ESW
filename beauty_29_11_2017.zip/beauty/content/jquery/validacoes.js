$(function() {
	//JQUERY VALIDATE
	$.validator.setDefaults({
		submitHandler: function() {
			alert("está tudo bem");
		}
	});

	// body...
	//VALIDAÇÃO LOGIN
	/*$("input[name='userName']").on("keyup",function(){
		if(($(this).val().trim() != "bebo")){
			$(this).css("border-color","red");
		}else{
			$(this).css("border-color","#66afe9");

		}
	});*/

	$('.btn-submit').on('click',function(){
		alert("ola malta ");
		if(($("input[name='userName']").val().trim() == "") || ($("input[name='userPass']").val().trim() == "")){
			alert("Campos inválidos");
		}else{
			alert("Campos validos");
		}
	});

	//VALIDANDO FORM REGISTRO
	$("#registroForm").validate({
		errorElement: 'span',
		rules:{
			nomeCompleto:"required",
			userName:{
				required:true,
				minlength: 6
			},
			email:{
				required:true,
				email:true
			},
			telefone:{
				required:true,
				number: true
			},
			palavraPasse:{
				required:true,
				minlength: 6
			},
			palavraPasseConfirmada:{
				required: true,
				minlength: 6,
				equalTo: "#palavraPasse"
			}
			
		},
		messages:{
			nomeCompleto:"campo obrigatório",
			userName:{
				required:"campo obrigatório",
				minlength: "Seu username deve ter no minimo 5 caracteres"
			},
			email:{
				required:"campo obrigatório",
				email:"Por favor digite um emai valido"
			},
			telefone:{
				required:"campo obrigatório",
				number: "digite apenas numero"
			},
			palavraPasse:{
				required:"campo obrigatório",
				minlength:"No minimo 6 caracteres"
			},

			palavraPasseConfirmada:{
				required:"campo obrigatório",
				minlength:"No minimo 6 caracteres",
				equalTo: "Senhas não combinam"
			}
			
		}
	});
});