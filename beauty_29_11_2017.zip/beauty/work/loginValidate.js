$(function() {
	/**valida login*/
	$('.btn-submit').on('click',function(){
		if(($("input[name='userName']").val().trim() == "") || ($("input[name='userPass']").val().trim() == "")){
			alert("Campos inválidos");
		}else{
			alert("Campos validos");
		}
	});
});