<!-- k_change -->
<?php $page = 'servico'; ?>
<!-- fim k_change --> 
<?php include 'header.php'; ?>
        
       
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="title">Os nossos <strong>Serviços</strong></h1>
                </div>
            </div>
           <!-- change -->
            <h3>Categoria: <strong>Cabelo</strong></h3>
            <div class="row">
                
                <div class="col-md-4 col-sm-6">
                    <div class="service">
                        <div class="row">
                            <div class="col-md-12"> <img src="content/img/barba.jpg" alt=""/>  </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12"> <h3>Corte de Barba</h3></div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6"><strong>Preço: </div>
                            <div class="col-md-6 col-sm-6"><span class="price">5.900AKz</span></div>
                        </div>
                        <div class="row">
                            <div class="col-md-12"> <a href="#" class="btn btn-default">Efectuar Marcação</a> </div>
                        </div>
                    </div>
                </div>
                
            </div>
           <!-- /change -->
        </div>
             
        
        
       
<?php include 'footer.php'; ?>
